package com.example.first_sb_project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.first_sb_project.dto.EmployeeRegistrationDto;
import com.example.first_sb_project.entity.EmpployeeEntity;
import com.example.first_sb_project.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	public List<EmpployeeEntity> getAllEmployees() {
		return employeeRepository.findAll();
	}

	public String employeeRegistration(EmployeeRegistrationDto dto) {
		System.out.println(dto.getName());
		System.out.println(dto.getDepartment());
		System.out.println(dto.getSalary());

		EmpployeeEntity e = new EmpployeeEntity();
		e.setName(dto.getName());
		e.setDepartment(dto.getDepartment());
		e.setSalary(dto.getSalary());

		employeeRepository.save(e);

		return "Successfully registered " + dto.getName();
	}

}
