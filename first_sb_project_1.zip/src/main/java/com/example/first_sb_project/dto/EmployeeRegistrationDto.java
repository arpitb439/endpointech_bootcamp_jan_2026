package com.example.first_sb_project.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class EmployeeRegistrationDto {

	@NotBlank(message = "Name must not be blank")
	@NotNull(message = "Name must not be Null")
	private String name;

	@NotNull(message = "Department must not be Null")
	private String department;

	@NotNull(message = "Salary must not be Null")
	private int salary;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}
