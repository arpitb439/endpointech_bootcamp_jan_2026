package com.example.first_sb_project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.first_sb_project.entity.EmpployeeEntity;

@Repository
public interface EmployeeRepository extends JpaRepository<EmpployeeEntity, Integer> {

}
