package com.example.first_sb_project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.first_sb_project.dto.EmployeeRegistrationDto;
import com.example.first_sb_project.entity.EmpployeeEntity;
import com.example.first_sb_project.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@GetMapping("/getallemployees")
	public List<EmpployeeEntity> getEmployees() {
		return employeeService.getAllEmployees();
	}

	@GetMapping("/hello/{name}")
	public String sayHello(@PathVariable String name) {
		return "Hello " + name;
	}

	@PostMapping("/registration")
	public String employeeRegistration(@RequestBody EmployeeRegistrationDto dto) {

		return employeeService.employeeRegistration(dto);
	}

}
