package endpointech;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class SaveDemo {

	public static void main(String[] args) {

		AnnotationConfiguration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.hbm.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Student student = new Student();
		student.setRollNumber(1);
		student.setName("Arpit");
		student.setBranch("CS");

		Transaction transaction = session.beginTransaction();
		session.save(student);
		System.out.println("Data saved");

		transaction.commit();
		session.close();
		factory.close();

	}

}
