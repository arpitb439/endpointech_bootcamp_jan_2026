package endpointech;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class SaveDemo {

	public static void main(String[] args) {

		AnnotationConfiguration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Person p = new Person();
		p.setPid(4);
		p.setName("Rahul");

		Address a1 = new Address();
		a1.setAddressId(105);
		a1.setAddress("Delhi2");

		Address a2 = new Address();
		a2.setAddressId(106);
		a2.setAddress("Mumbai2");

		/* Set relation */
		a1.setPerson(p);
		a2.setPerson(p);

		Set<Address> addresses = new HashSet<>();
		addresses.add(a1);
		addresses.add(a2);

		p.setAddresses(addresses);

		Transaction transaction = session.beginTransaction();

		session.save(p);

		transaction.commit();
		System.out.println("Data saved");

		session.close();
		factory.close();

	}

}
